package com.infy.Ekart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.Ekart.dto.NotificationDTO;
import com.infy.Ekart.repository.NotificationRepository;

@Service
public class NotificationService {
 
	@Autowired
	NotificationRepository rep;
	public String add(NotificationDTO notificationDTO)
	{
		rep.save(NotificationDTO.createEntity(notificationDTO));
		return "Notifications added to user";
	}
}
