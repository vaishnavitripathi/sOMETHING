package com.infy.Ekart.dto;

import com.infy.Ekart.entity.Notification;

public class NotificationDTO {
	private int NotificationId;
	private int userId;
	private String message;
	private String messageType;
	public NotificationDTO()
	{}
	
	public NotificationDTO(int notificationId, int userId, String message, String messageType) {
		super();
		NotificationId = notificationId;
		this.userId = userId;
		this.message = message;
		this.messageType = messageType;
	}

	public int getNotificationId() {
		return NotificationId;
	}

	public void setNotificationId(int notificationId) {
		NotificationId = notificationId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public static Notification createEntity(NotificationDTO notificationDTO) {
		Notification notification=new Notification();
		notification.setMessage(notificationDTO.getMessage());
		notification.setMessageType(notificationDTO.getMessageType());
		notification.setUserId(notificationDTO.getUserId());
		return notification;
	}
	
}
