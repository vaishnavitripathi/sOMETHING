package com.infy.Ekart.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.infy.Ekart.entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification,Integer>{

	public Notification findByUserId(int userId);
}
