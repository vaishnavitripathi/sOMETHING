package com.infy.Ekart.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infy.Ekart.entity.OrderDetails;


public interface OrderRepository extends JpaRepository<OrderDetails,Integer>{

	@Query
	public ArrayList<OrderDetails> findByProductIdAndSellerName(Integer productId,String SellerName);

	@Query
	public ArrayList<OrderDetails> findBySellerName(String sellerName);
}
