package com.infy.Ekart.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.Ekart.dto.OrderDTO;
import com.infy.Ekart.entity.OrderDetails;
import com.infy.Ekart.repository.OrderRepository;

@Service
public class OrderService {

	@Autowired
	OrderRepository rep;
	public ArrayList<OrderDetails>viewOrders(int productId,String sellerName) {
		return rep.findByProductIdAndSellerName(productId,sellerName);
		
	}
	public ArrayList<OrderDTO> viewSellerOrders(String sellerName) {
		ArrayList<OrderDetails>orders= rep.findBySellerName(sellerName);
		ArrayList<OrderDTO>ordersdto=new ArrayList<>();
		for(int i=0;i<orders.size();i++)
		{
			ordersdto.add(OrderDTO.createOrderDTO(orders.get(i)));
		}
		return ordersdto;
	}
	public String updateOrder(int userId, int orderId) {
		Optional<OrderDetails>optionalOrder=rep.findById(orderId);
		if(optionalOrder.isPresent())
		{
			OrderDetails order=optionalOrder.get();
			order.setOrderStatus("delivered");
			rep.save(order);
			return "order updated";
		}
		return "can't find any order with that userId";
	}

}
