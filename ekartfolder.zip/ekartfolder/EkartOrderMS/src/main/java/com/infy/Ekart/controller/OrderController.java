package com.infy.Ekart.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.Ekart.dto.OrderDTO;
import com.infy.Ekart.entity.OrderDetails;
import com.infy.Ekart.service.OrderService;

@RestController
public class OrderController {

	@Autowired
	OrderService orderService;
	@GetMapping("/products/{productId}/{sellerName}")
	public ArrayList<OrderDetails> viewOrders(@PathVariable("productId") int productId,@PathVariable("sellerName") String sellerName)
	{
		return orderService.viewOrders(productId,sellerName);
	}
	@GetMapping("/{sellerName}/sellerOrders")
	public ArrayList<OrderDTO> viewSellerOrders(@PathVariable("sellerName")String sellerName)
	{
		return orderService.viewSellerOrders(sellerName);
	}
	@PutMapping("/{userId}/orders/{orderId}/deliver")
    public String updateOrder(@PathVariable("userId") int userId,@PathVariable("orderId") int orderId)
    {
		return orderService.updateOrder(userId,orderId);
    }
}
