package com.infy.Ekart.dto;

import java.time.LocalDateTime;

import com.infy.Ekart.entity.OrderDetails;


public class OrderDTO {
	private int orderId;
	private int userId;
	private LocalDateTime dateOfOrder;
	private int productId;
	private int quantity;
	private double totalPrice;
	private int addressId;
	private String orderStatus;
	private String paymentThrough;
	private LocalDateTime dateOfDelivery;
	private String sellerName;
	private String productName;
	public OrderDTO()
	{}
	public OrderDTO(int orderId, int userId, LocalDateTime dateOfOrder, int productId,
			int quantity, double totalPrice, int addressId, String orderStatus, String paymentThrough,
			LocalDateTime dateOfDelivery, String sellerName,String productName) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		this.dateOfOrder = dateOfOrder;
		this.productId = productId;
		this.quantity = quantity;
		this.totalPrice = totalPrice;
		this.addressId = addressId;
		this.orderStatus = orderStatus;
		this.paymentThrough = paymentThrough;
		this.dateOfDelivery = dateOfDelivery;
		this.sellerName = sellerName;
		this.productName=productName;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public LocalDateTime getDateOfOrder() {
		return dateOfOrder;
	}
	public void setDateOfOrder(LocalDateTime dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getPaymentThrough() {
		return paymentThrough;
	}
	public void setPaymentThrough(String paymentThrough) {
		this.paymentThrough = paymentThrough;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	
	public void setDateOfDelivery(LocalDateTime dateOfDelivery) {
		this.dateOfDelivery = dateOfDelivery;
	}
	public LocalDateTime getDateOfDelivery() {
		return dateOfDelivery;
	}
	public static OrderDetails createEntity(OrderDTO orderDTO)
	{
		OrderDetails o=new OrderDetails();
		return o;
	}
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public static OrderDTO createOrderDTO(OrderDetails orderDetails) {
		OrderDTO dto=new OrderDTO();
		dto.setUserId(orderDetails.getUserId());
		dto.setOrderId(orderDetails.getOrderId());
		dto.setProductName(orderDetails.getProductName());
		dto.setQuantity(orderDetails.getQuantity());
		dto.setTotalPrice(orderDetails.getTotalPrice());
		dto.setDateOfOrder(orderDetails.getDateOfOrder());
		dto.setOrderStatus(orderDetails.getOrderStatus());
		return dto;
		
	}
}
