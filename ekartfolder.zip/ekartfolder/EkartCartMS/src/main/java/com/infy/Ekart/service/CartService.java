package com.infy.Ekart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.Ekart.dto.CartDTO;
import com.infy.Ekart.dto.CartUserDTO;
import com.infy.Ekart.dto.Holder;
import com.infy.Ekart.entity.Cart;
import com.infy.Ekart.repository.CartRepository;

@Service
public class CartService {
	
	@Autowired
	CartRepository rep;
	
	@Autowired
	ModelMapper model;
//	public ArrayList<CartDTO> viewCart(String sellerName) {
//		ArrayList<Cart> cartdetails=rep.findBySellerName(sellerName);
//		ArrayList<CartDTO> dto=new ArrayList<>();
//		for(int i=0;i<cartdetails.size();i++)
//		{
//			dto.add(CartDTO.createDTO(cartdetails.get(i)));
//		}
//		return dto;
//	}

	public List <Cart> view(String sellerName) {
		
		return rep.findBySellerName(sellerName);
	}
	
	public String updateCart(Integer userId, Integer sellerId,CartDTO cart) {
//		Cart cart=rep.findByUserIdAndProductNameAndSellerName(userId,);
//		double price=cart.getPrice()-(cart.getPrice()*cart.getDiscount()/100);
//		if(cart.getCartOfferPrice()<price)
//		{
//		cart.setCartOfferPrice(cartDTO.getCartOfferPrice());
//		cart.setQuantity(cartDTO.getQuantity());
//		//cart.setTotalPrice(cart.getCartOfferPrice()*cart.getQuantity());
//		rep.save(cart);
//		return "offer is provided to user";
//	    }
//		else
//		{
//			return "cartoffer  price should be less than price of product";	
		
//		}
		
		CartUserDTO cart1=new CartUserDTO();
		cart1.setUserId(userId);
		cart1.setSellerId(sellerId);
		cart1.setProductId(cart.getProductId());
		cart1.setProductName(cart.getProductName());
		cart1.setQuantity(cart.getQuantity());
		cart1.setTotalPrice(cart.getTotalPrice());
		cart1.setCartOfferPrice(cart.getCartOfferPrice());
		cart1.setSellerName(cart.getSellerName());
		cart1.setCategory(cart.getCategory());
		cart1.setPrice(cart.getPrice());
		cart1.setDiscount(cart.getDiscount());
		cart1.setDeliveryCharge(cart.getDeliveryCharge());
		
		rep.save(model.map(cart1,Cart.class));
		
		return "Cart Details Updated";
	}
	
	public String modify(Holder hold,Integer userId,String productName) 
	{
		
	Optional<Cart> c= rep.findByUserIdAndProductName(userId, productName);	
	
	c.get().setCartOfferPrice(hold.getCartOfferPrice());
	
	rep.save(c.get());
	
	return "Details Modified";
		
		
	}
}


