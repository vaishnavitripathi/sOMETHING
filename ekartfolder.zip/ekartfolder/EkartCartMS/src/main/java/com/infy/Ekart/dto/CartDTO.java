package com.infy.Ekart.dto;

import com.infy.Ekart.dto.CartDTO;
import com.infy.Ekart.entity.Cart;

public class CartDTO {

	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Integer totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Double getCartOfferPrice() {
		return cartOfferPrice;
	}
	public void setCartOfferPrice(Double cartOfferPrice) {
		this.cartOfferPrice = cartOfferPrice;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getDiscount() {
		return discount;
	}
	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	public Double getDeliveryCharge() {
		return deliveryCharge;
	}
	public void setDeliveryCharge(Double deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}
	
	public CartDTO(String productName, Integer quantity, Integer totalPrice, Double cartOfferPrice, String sellerName,
			Integer productId, String category, Double price, Double discount, Double deliveryCharge) {
		super();
		this.productName = productName;
		this.quantity = quantity;
		this.totalPrice = totalPrice;
		this.cartOfferPrice = cartOfferPrice;
		this.sellerName = sellerName;
		this.productId = productId;
		this.category = category;
		this.price = price;
		this.discount = discount;
		this.deliveryCharge = deliveryCharge;
	}
	private String productName;
	private Integer quantity;
	private Integer totalPrice;
	private Double cartOfferPrice;
	private String sellerName;
	private Integer productId;
	private String category;
	private Double price;
	private Double discount;
	private Double deliveryCharge;
	
	public CartDTO() {
	}
}

	