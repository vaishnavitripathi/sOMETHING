package com.infy.Ekart.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infy.Ekart.dto.CartDTO;
import com.infy.Ekart.dto.Holder;
import com.infy.Ekart.entity.Cart;
import com.infy.Ekart.service.CartService;

@RestController
public class CartController {

	@Autowired
	CartService service;
//	@GetMapping("/productsincart/{sellerName}")
//	public ResponseEntity<ArrayList<CartDTO>> viewCart(@PathVariable("sellerName") String sellerName)
//	{
//		ArrayList<CartDTO> cart=service.viewCart(sellerName);
//		return ResponseEntity.ok(cart);
//	}
	@PostMapping("/updatecart/{userId}/{sellerId}/add")
	public ResponseEntity<String> updateCart(@PathVariable("userId") Integer userId ,@PathVariable("sellerId") Integer sellerId,@RequestBody CartDTO cartDTO)
	{
		String msg=service.updateCart(userId,sellerId,cartDTO);
		return ResponseEntity.ok(msg);
	}
	
	@GetMapping("/searchcartseller/{sellerName}")
	public List<Cart> viewCart(@PathVariable String sellerName){
		
		return service.view(sellerName);
		
	}
	@PostMapping("/updatecart/{userId}/{productName}")
	public String modifyPrice(@PathVariable("userId") Integer userId,@PathVariable("productName") String productName,@RequestBody Holder hold) {
		
		return service.modify(hold, userId, productName);
	}
}
