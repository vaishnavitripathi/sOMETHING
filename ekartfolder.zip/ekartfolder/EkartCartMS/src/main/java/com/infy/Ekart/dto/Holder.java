package com.infy.Ekart.dto;

public class Holder {
	
	Double cartOfferPrice;
	public Holder(Double cartOfferPrice) {
		super();
		this.cartOfferPrice = cartOfferPrice;
	}
	public Double getCartOfferPrice() {
		return cartOfferPrice;
	}
	public void setCartOfferPrice(Double cartOfferPrice) {
		this.cartOfferPrice = cartOfferPrice;
	}
	public Holder() {
		
	}

}
